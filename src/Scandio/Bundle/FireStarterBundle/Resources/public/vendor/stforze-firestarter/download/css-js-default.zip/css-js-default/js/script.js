$(document).ready(function(){
// Code
	
	$('a').click(function(){
		$('div p').css({ 'color': 'red' });
	});

});